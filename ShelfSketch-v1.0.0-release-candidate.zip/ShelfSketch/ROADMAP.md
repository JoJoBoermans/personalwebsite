# Roadmap after validation

These features are documented only and must not be built before MVP evidence supports them.

## Product extensions

- Multiple shelves and compartments
- Drawer top-down mode
- Door, hinge, pipe, and fixed-obstacle geometry
- Accessibility-aware retrieval zones
- Multiple locally stored projects in IndexedDB
- Private share links and cloud sync
- Product presets and optional retailer integrations
- Affiliate modules on editorial pages
- Advertising on content pages

## Explicitly deferred advanced technology

- Camera measurement
- Computer vision
- Augmented reality
- Three-dimensional packing
- AI-generated recommendations
- Native mobile applications
